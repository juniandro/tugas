const checkRole = (allowedRoles) => {
  return (req, res, next) => {
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).send('Access Denied: Insufficient permissions');
    }
    next();
  };
};

module.exports = checkRole;
const { Item } = require('../models');

// Dashboard - Tampilkan semua barang aktif
exports.getDashboard = async (req, res) => {
  try {
    const items = await Item.findAll({
      where: { is_active: true },
      order: [['created_at', 'DESC']]
    });

    res.render('dashboard', { 
      items, 
      user: req.user 
    });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Tampilkan form tambah barang
exports.showAddForm = (req, res) => {
  res.render('addItem', { user: req.user, error: null });
};

// Proses tambah barang (AUDIT TRAIL: created_by dari req.user.username)
exports.createItem = async (req, res) => {
  try {
    const { item_name, category, price, stock_qty, min_stock, storage_location } = req.body;

    // Validasi input
    if (!item_name || !category || !price || !stock_qty || !min_stock || !storage_location) {
      return res.render('addItem', { 
        user: req.user, 
        error: 'Semua field harus diisi' 
      });
    }

    // AUDIT TRAIL: created_by diambil dari JWT token
    await Item.create({
      item_name,
      category,
      price: parseInt(price),
      stock_qty: parseInt(stock_qty),
      min_stock: parseInt(min_stock),
      storage_location,
      is_active: true,
      created_by: req.user.username // OTOMATIS dari token JWT
    });

    res.redirect('/dashboard');
  } catch (error) {
    console.error(error);
    res.render('addItem', { 
      user: req.user, 
      error: 'Gagal menambahkan barang' 
    });
  }
};

// Tampilkan form edit barang
exports.showEditForm = async (req, res) => {
  try {
    const item = await Item.findByPk(req.params.id);

    if (!item || !item.is_active) {
      return res.status(404).send('Barang tidak ditemukan');
    }

    res.render('editItem', { 
      item, 
      user: req.user, 
      error: null 
    });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Proses update barang (AUDIT TRAIL: updated_by dari req.user.username)
exports.updateItem = async (req, res) => {
  try {
    const { item_name, category, price, stock_qty, min_stock, storage_location } = req.body;
    const item = await Item.findByPk(req.params.id);

    if (!item || !item.is_active) {
      return res.status(404).send('Barang tidak ditemukan');
    }

    // AUDIT TRAIL: updated_by diambil dari JWT token
    await item.update({
      item_name,
      category,
      price: parseInt(price),
      stock_qty: parseInt(stock_qty),
      min_stock: parseInt(min_stock),
      storage_location,
      updated_by: req.user.username // OTOMATIS dari token JWT
      // updated_at akan otomatis terupdate oleh Sequelize
    });

    res.redirect('/dashboard');
  } catch (error) {
    console.error(error);
    const item = await Item.findByPk(req.params.id);
    res.render('editItem', { 
      item, 
      user: req.user, 
      error: 'Gagal mengupdate barang' 
    });
  }
};

// SOFT DELETE - Discontinue barang (UPDATE is_active = 0)
exports.deleteItem = async (req, res) => {
  try {
    const item = await Item.findByPk(req.params.id);

    if (!item) {
      return res.status(404).send('Barang tidak ditemukan');
    }

    // SOFT DELETE: Tidak menggunakan DELETE, tapi UPDATE is_active = 0
    await item.update({
      is_active: false,
      updated_by: req.user.username // Audit trail tetap tercatat
    });

    res.redirect('/dashboard');
  } catch (error) {
    console.error(error);
    res.status(500).send('Gagal menghapus barang');
  }
};
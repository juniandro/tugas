const express = require('express');
const router = express.Router();
const itemController = require('../controllers/itemController');
const verifyToken = require('../middleware/auth');
const checkRole = require('../middleware/roleCheck');

// Dashboard - Semua user yang sudah login
router.get('/dashboard', verifyToken, itemController.getDashboard);

// Route khusus Manager (Tambah & Hapus Barang)
router.get('/items/add', verifyToken, checkRole(['manager']), itemController.showAddForm);
router.post('/items/add', verifyToken, checkRole(['manager']), itemController.createItem);
router.post('/items/delete/:id', verifyToken, checkRole(['manager']), itemController.deleteItem);

// Route untuk Manager & Admin (Edit Barang)
router.get('/items/edit/:id', verifyToken, checkRole(['manager', 'admin']), itemController.showEditForm);
router.post('/items/edit/:id', verifyToken, checkRole(['manager', 'admin']), itemController.updateItem);

module.exports = router;
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Route untuk halaman login
router.get('/login', authController.showLogin);

// Route untuk proses login
router.post('/login', authController.login);

// Route untuk logout
router.get('/logout', authController.logout);

module.exports = router;
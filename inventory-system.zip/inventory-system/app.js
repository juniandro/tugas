require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');
const bcrypt = require('bcryptjs');

const db = require('./models');
const authRoutes = require('./routes/authRoutes');
const itemRoutes = require('./routes/itemRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static files (jika diperlukan)
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/', authRoutes);
app.use('/', itemRoutes);

// Root redirect
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Database Sync & Seeding
const initializeDatabase = async () => {
  try {
    await db.sequelize.sync({ force: false });
    console.log('✓ Database synced');

    // Seed dummy users jika belum ada
    const userCount = await db.User.count();
    
    if (userCount === 0) {
      console.log('Seeding dummy users...');
      
      const hashedPassword = await bcrypt.hash('password123', 10);

      await db.User.bulkCreate([
        {
          username: 'manager',
          password: hashedPassword,
          role: 'manager'
        },
        {
          username: 'admin',
          password: hashedPassword,
          role: 'admin'
        }
      ]);

      console.log('✓ Dummy users created:');
      console.log('  - Manager: manager / password123');
      console.log('  - Admin: admin / password123');
    }

    // Seed dummy items untuk testing (optional)
    const itemCount = await db.Item.count();
    
    if (itemCount === 0) {
      console.log('Seeding dummy items...');
      
      await db.Item.bulkCreate([
        {
          item_name: 'Laptop Dell XPS 13',
          category: 'Elektronik',
          price: 15000000,
          stock_qty: 5,
          min_stock: 3,
          storage_location: 'Rak A-01',
          is_active: true,
          created_by: 'manager'
        },
        {
          item_name: 'Mouse Logitech M170',
          category: 'Elektronik',
          price: 75000,
          stock_qty: 2,
          min_stock: 5,
          storage_location: 'Rak A-02',
          is_active: true,
          created_by: 'manager'
        },
        {
          item_name: 'Meja Kerja Kayu Jati',
          category: 'Furniture',
          price: 2500000,
          stock_qty: 15,
          min_stock: 10,
          storage_location: 'Gudang Belakang',
          is_active: true,
          created_by: 'admin'
        },
        {
          item_name: 'Kertas A4 70gsm',
          category: 'ATK',
          price: 45000,
          stock_qty: 0,
          min_stock: 20,
          storage_location: 'Rak B-05',
          is_active: true,
          created_by: 'manager'
        }
      ]);

      console.log('✓ Dummy items created');
    }

  } catch (error) {
    console.error('Database initialization error:', error);
    process.exit(1);
  }
};

// Start Server
initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`\n🚀 Server running on http://localhost:${PORT}`);
    console.log(`📦 Inventory System is ready!`);
    console.log(`\n📝 Login with:`);
  });
});
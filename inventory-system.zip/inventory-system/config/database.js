require('dotenv').config();
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: 'mysql',
    logging: false,
    timezone: '+07:00',
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  }
);

// Test koneksi database
sequelize.authenticate()
  .then(() => {
    console.log('✓ Database connection established successfully');
  })
  .catch(err => {
    console.error('✗ Unable to connect to database:', err.message);
  });

module.exports = sequelize;
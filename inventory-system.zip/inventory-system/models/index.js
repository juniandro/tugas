const sequelize = require('../config/database');
const User = require('./user');
const Item = require('./item');

// Sinkronisasi models dengan database
const db = {
  sequelize,
  User,
  Item,
  // Method untuk sync database
  sync: async () => {
    try {
      await sequelize.sync({ alter: false });
      console.log('✓ Database & Models synced successfully');
    } catch (error) {
      console.error('✗ Database sync error:', error);
      throw error;
    }
  }
};

module.exports = db;